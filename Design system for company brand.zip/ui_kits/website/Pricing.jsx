(() => {
window.K = window.K || {}; const K = window.K;
const { wrap, mono, Placeholder } = K;
K.Pricing = function Pricing({ ds }) {
  const { Button, Eyebrow, Card, Tag, Input } = ds;
  const tiers = [
    ['Portfolio','3,200','Up to 5 pages · Framer or Webflow · 3 weeks',['Design + build','CMS walkthrough','1 month of fixes'],'surface'],
    ['Brochure','5,800','Up to 8 pages · CMS · 4–5 weeks',['Everything in Portfolio','Copy editing','Basic SEO setup','Contact + booking forms'],'tint'],
    ['Shop','8,400','Shopify · unlimited products · 6 weeks',['Everything in Brochure','Checkout + shipping setup','Product photo direction','Launch-day support'],'surface'],
  ];
  return <main>
    <section style={{ ...wrap, padding:'64px var(--gutter) 48px', display:'grid', gridTemplateColumns:'2fr 1fr', gap:48, alignItems:'end' }}>
      <div><Eyebrow index={3} total={3}>Pricing</Eyebrow>
      <h1 style={{ font:'var(--text-display-xl)', letterSpacing:'var(--tracking-display)', margin:'24px 0 0', fontSize:104, maxWidth:'12ch' }}>One number, <em>up front.</em></h1></div>
      <p style={{ font:'var(--text-body-l)', color:'var(--text-secondary)', margin:0 }}>Prices in EUR, excluding VAT. Half at kickoff, half at launch. No retainers unless you ask for one.</p>
    </section>
    <section style={{ ...wrap, display:'grid', gridTemplateColumns:'repeat(3, minmax(0,1fr))', gap:20 }}>
      {tiers.map(([t,p,m,items,tone],i)=><Card key={t} tone={tone} index={i+1} eyebrow={t} padding={28}>
        <div style={{ display:'flex', alignItems:'baseline', gap:6, color:'var(--text-primary)' }}><span style={{ font:'var(--text-display-l)', letterSpacing:'var(--tracking-display)', fontSize:72 }}>{p}</span><span style={{...mono}}>eur</span></div>
        <div style={{ ...mono, color:'var(--text-tertiary)', margin:'8px 0 24px' }}>{m}</div>
        <ul style={{ listStyle:'none', margin:0, padding:0, display:'flex', flexDirection:'column', gap:10, borderTop:'var(--border-1)' }}>{items.map(x=><li key={x} style={{ padding:'10px 0', borderBottom:'var(--border-1)', color:'var(--text-primary)' }}>{x}</li>)}</ul>
        <div style={{ marginTop:28 }}><Button variant={tone==='tint'?'accent':'primary'} arrow style={{ width:'100%', justifyContent:'center' }}>Start with {t}</Button></div>
      </Card>)}
    </section>
    <section style={{ ...wrap, padding:'96px var(--gutter) 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:64 }}>
      <div><Eyebrow tone="tertiary">Small jobs</Eyebrow>
        <h2 style={{ font:'var(--text-display-l)', letterSpacing:'var(--tracking-display)', fontSize:56, margin:'20px 0 24px' }}>Half a day, <em>480.</em></h2>
        <p style={{ font:'var(--text-body-l)', color:'var(--text-secondary)', margin:0, maxWidth:'40ch' }}>Fix a page, speed up a shop, sort out a menu. Tell me what's wrong and I'll say if half a day covers it.</p></div>
      <form style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, padding:28, background:'var(--bg-surface)', border:'var(--border-1)', borderRadius:'var(--radius-m)' }} onSubmit={e=>e.preventDefault()}>
        <Input label="Name" placeholder="Ana" /><Input label="Email" placeholder="ana@studio.com" />
        <Input label="What's wrong?" multiline placeholder="The shop takes ages to load on phones…" style={{ gridColumn:'1 / -1' }} />
        <div style={{ gridColumn:'1 / -1', display:'flex', justifyContent:'space-between', alignItems:'center' }}><span style={{ ...mono, color:'var(--text-tertiary)' }}>Reply within a day</span><Button type="submit" arrow>Send</Button></div>
      </form>
    </section>
  </main>;
};
})();
