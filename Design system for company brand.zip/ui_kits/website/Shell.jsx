(() => {
window.K = window.K || {}; const K = window.K;
K.mono = { font:'var(--text-mono)', letterSpacing:'var(--tracking-mono)', textTransform:'uppercase' };
K.wrap = { maxWidth:'var(--container)', margin:'0 auto', padding:'0 var(--gutter)' };
const { mono, wrap } = K;
K.Placeholder = function Placeholder({ label, ratio='4/3', a='--ink-200', b='--ink-100', style }) {
  return <div style={{ aspectRatio:ratio, borderRadius:'var(--radius-m)', background:`repeating-linear-gradient(135deg,var(${a}) 0 6px,var(${b}) 6px 12px)`, display:'grid', placeItems:'center', color:'var(--text-secondary)', ...mono, ...style }}>{label}</div>;
};
K.Nav = function Nav({ page, onNav }) {
  const items = ['Home','Services','Pricing'];
  return <header style={{ ...wrap, display:'flex', alignItems:'center', justifyContent:'space-between', height:72 }}>
    <a href="#" onClick={e=>{e.preventDefault();onNav('Home')}} style={{ font:'var(--text-display-s)', fontSize:28, letterSpacing:'var(--tracking-display)', textDecoration:'none' }}>Studio<span style={{color:'var(--accent)'}}>.</span></a>
    <nav style={{ display:'flex', gap:28, ...mono }}>{items.map(i=><a key={i} href="#" onClick={e=>{e.preventDefault();onNav(i)}} style={{ textDecoration: page===i?'underline':'none', color:'var(--text-primary)' }}>{i}</a>)}<a href="#" style={{textDecoration:'none'}}>Contact ↗</a></nav>
  </header>;
};
K.Footer = function Footer() {
  return <footer style={{ borderTop:'var(--border-1)', marginTop:'var(--space-9)' }}><div style={{ ...wrap, display:'grid', gridTemplateColumns:'2fr 1fr 1fr', gap:32, padding:'48px var(--gutter) 40px' }}>
    <div style={{ font:'var(--text-display-m)', letterSpacing:'var(--tracking-display)', fontSize:40 }}>Have a project? <em>Say hello.</em></div>
    <div style={{ display:'flex', flexDirection:'column', gap:10, ...mono }}><a href="#" style={{textDecoration:'none'}}>hello@studio.com</a><a href="#" style={{textDecoration:'none'}}>Instagram ↗</a><a href="#" style={{textDecoration:'none'}}>Are.na ↗</a></div>
    <div style={{ display:'flex', flexDirection:'column', gap:10, ...mono, color:'var(--text-tertiary)' }}><span>Lisbon · Remote</span><span>© 2026 Studio</span></div>
  </div></footer>;
};
})();
