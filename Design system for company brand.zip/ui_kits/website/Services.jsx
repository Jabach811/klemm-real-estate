(() => {
window.K = window.K || {}; const K = window.K;
const { wrap, mono, Placeholder } = K;
K.Services = function Services({ ds, onNav }) {
  const { Button, Eyebrow, Card, Tag, Accordion } = ds;
  const svc = [
    ['Brochure site','For practices and studios that need to look like they mean it.','3–5 pages · CMS · 4 weeks',['Webflow','Framer']],
    ['Shop','Products, checkout, the lot. Set up so you can add stock yourself.','Shopify · 6 weeks',['Shopify']],
    ['Portfolio','Your work, big. Very little else.','Any size · 3 weeks',['Framer','Custom']],
  ];
  return <main>
    <section style={{ ...wrap, padding:'64px var(--gutter) 48px' }}>
      <Eyebrow index={2} total={3}>Services</Eyebrow>
      <h1 style={{ font:'var(--text-display-xl)', letterSpacing:'var(--tracking-display)', margin:'24px 0 0', fontSize:104, maxWidth:'12ch' }}>Three things I do <em>well.</em></h1>
    </section>
    <section style={{ ...wrap, display:'grid', gridTemplateColumns:'repeat(3, minmax(0,1fr))', gap:20 }}>
      {svc.map(([t,d,m,tags],i)=><Card key={t} index={i+1} eyebrow={m} title={t}>{d}<div style={{ display:'flex', gap:8, marginTop:20 }}>{tags.map(x=><Tag key={x}>{x}</Tag>)}</div></Card>)}
    </section>
    <section style={{ ...wrap, padding:'96px var(--gutter) 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:48, alignItems:'center' }}>
      <Placeholder label="Fig. 1 — process, work-in-progress photo" ratio="4/5" a="--navy-200" b="--ink-100" />
      <div><Eyebrow tone="tertiary">Fig. 1 — Also</Eyebrow>
        <h2 style={{ font:'var(--text-display-l)', letterSpacing:'var(--tracking-display)', fontSize:56, margin:'20px 0 24px' }}>Small jobs, <em>too.</em></h2>
        <p style={{ font:'var(--text-body-l)', color:'var(--text-secondary)', margin:'0 0 28px', maxWidth:'44ch' }}>A page that needs fixing. A shop that loads slowly. A menu nobody can find. Half a day, fixed fee, usually this week.</p>
        <Button variant="secondary" arrow onClick={()=>onNav('Pricing')}>See the fixed fees</Button></div>
    </section>
    <section style={{ ...wrap, padding:'96px var(--gutter) 0' }}>
      <Eyebrow>Questions people ask</Eyebrow>
      <div style={{ marginTop:24 }}><Accordion items={[
        {q:'How long does a site take?',a:'Brochure sites take about four weeks, shops about six. I only run two projects at a time, so dates are real.'},
        {q:'Can I edit it myself afterwards?',a:'Yes. Every site ships on a CMS with a 20-minute walkthrough recorded for you.'},
        {q:'Do you write the copy?',a:'I edit it. You know your business; I make it read well and fit the design.'},
        {q:'What if I already have a brand?',a:'Great, send the files. If you don’t, I set type and colour as part of the job.'}]} /></div>
    </section>
  </main>;
};
})();
