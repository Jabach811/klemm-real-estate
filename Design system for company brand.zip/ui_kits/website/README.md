# Website UI kit
Marketing site for the (unnamed) web design studio. Three screens: Home, Services, Pricing, switched by the nav in index.html.
Composes components from `components/core` via the generated bundle. Shell.jsx holds Nav, Footer and the striped Placeholder.