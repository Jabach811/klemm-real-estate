(() => {
window.K = window.K || {}; const K = window.K;
const { wrap, mono, Placeholder } = K;
K.Home = function Home({ ds, onNav }) {
  const { Button, Eyebrow, Card, Tag } = ds;
  const img = (w,a,b,p=',') => <span style={{whiteSpace:'nowrap'}}><span style={{ display:'inline-block', width:w, height:'0.62em', verticalAlign:'-0.08em', borderRadius:6, background:`repeating-linear-gradient(135deg,var(${a}) 0 5px,var(${b}) 5px 10px)` }} />{p}</span>;
  return <main>
    <section style={{ ...wrap, padding:'64px var(--gutter) 40px' }}>
      <Eyebrow index={1} total={3}>Web design, by one person</Eyebrow>
      <h1 style={{ font:'var(--text-display-xl)', letterSpacing:'var(--tracking-display)', margin:'24px 0 0', maxWidth:'14ch' }}>I make websites for people who <em>notice.</em></h1>
      <div style={{ display:'flex', gap:32, alignItems:'flex-end', justifyContent:'space-between', marginTop:40, flexWrap:'wrap' }}>
        <p style={{ font:'var(--text-lead)', color:'var(--text-secondary)', margin:0, maxWidth:'40ch' }}>Small studios, shops and practices. Designed and built by me, start to finish, in about six weeks.</p>
        <div style={{ display:'flex', gap:12 }}><Button arrow>Start a project</Button><Button variant="secondary" onClick={()=>onNav('Pricing')}>Pricing</Button></div>
      </div>
    </section>
    <section style={{ ...wrap, padding:'24px var(--gutter)' }}><Placeholder label="Hero — recent site, full-bleed screenshot" ratio="21/9" a="--teal-200" b="--teal-100" /></section>
    <section style={{ ...wrap, padding:'96px var(--gutter) 0' }}>
      <Eyebrow index={2} total={3}>Selected work</Eyebrow>
      <p style={{ font:'var(--text-display-m)', letterSpacing:'var(--tracking-display)', lineHeight:1.15, margin:'24px 0 48px', maxWidth:'26ch' }}>Lately: a bakery {img('1.4em','--ink-200','--ink-100')} a ceramicist {img('1em','--teal-200','--teal-100')} a small law firm {img('1.6em','--navy-200','--ink-100','')} and a bookshop {img('1.1em','--orange-100','--ink-100','.')}</p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, minmax(0,1fr))', gap:20 }}>
        {[['Loaf & Co.','Bakery','Shop · 2026'],['Ana Reis Ceramics','Ceramicist','Portfolio · 2026'],['Duarte & Filha','Law firm','Brochure · 2025']].map(([t,e,m],i)=><Card key={t} index={i+1} eyebrow={e} title={t} media href="#">{m}</Card>)}
      </div>
    </section>
    <section style={{ ...wrap, padding:'96px var(--gutter) 0', display:'grid', gridTemplateColumns:'1fr 1fr', gap:48 }}>
      <div><Eyebrow index={3} total={3}>How I work</Eyebrow><h2 style={{ font:'var(--text-display-l)', letterSpacing:'var(--tracking-display)', margin:'24px 0 0', fontSize:64 }}>Plain process. <em>One price.</em></h2></div>
      <div style={{ display:'flex', flexDirection:'column', gap:0, borderTop:'var(--border-1)', alignSelf:'end' }}>
        {[['Talk','A 30-minute call. You tell me what the site has to do.'],['Design','Two rounds. Real content, no lorem ipsum.'],['Build','A CMS you can edit. Fast, accessible, yours.'],['Launch','Then a month of fixes, on me.']].map(([t,d],i)=><div key={t} style={{ display:'grid', gridTemplateColumns:'40px 120px 1fr', gap:16, padding:'18px 0', borderBottom:'var(--border-1)', alignItems:'baseline' }}><span style={{...mono,color:'var(--text-tertiary)'}}>0{i+1}</span><span style={{ font:'var(--text-display-s)', fontSize:24, letterSpacing:'var(--tracking-display)' }}>{t}</span><span style={{ font:'var(--text-body)', color:'var(--text-secondary)' }}>{d}</span></div>)}
      </div>
    </section>
  </main>;
};
})();
