Content card: eyebrow → serif title → body, optional 4:3 media. Flat with a 1px border; shadow only on hover when it's a link.
```jsx
<Card index={1} eyebrow="Bakery" title="Loaf & Co." media href="#">Shop site, 2026</Card>
<Card tone="tint" title="Fixed price">One number, no surprises.</Card>
```