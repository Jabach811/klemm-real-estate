import * as React from 'react';
export interface EyebrowProps { index?: number; total?: number; tone?: 'primary'|'secondary'|'tertiary'|'accent'; children?: React.ReactNode; style?: React.CSSProperties; }
export function Eyebrow(props: EyebrowProps): JSX.Element;