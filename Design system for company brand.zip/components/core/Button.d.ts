import * as React from 'react';
/** @startingPoint section="Core" subtitle="Pill button, four variants" viewport="700x180" */
export interface ButtonProps extends React.HTMLAttributes<HTMLElement> {
  /** primary = ink, turns orange on hover. accent = orange (one per screen). */
  variant?: 'primary' | 'accent' | 'secondary' | 'ghost';
  size?: 's' | 'm' | 'l';
  /** Trailing arrow: true → "→", 'external' → "↗" */
  arrow?: boolean | 'external';
  disabled?: boolean;
  /** Renders an <a> when set */
  href?: string;
  children?: React.ReactNode;
}
export function Button(props: ButtonProps): JSX.Element;