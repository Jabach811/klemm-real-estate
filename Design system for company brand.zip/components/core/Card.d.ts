import * as React from 'react';
/** @startingPoint section="Core" subtitle="Bordered card with eyebrow, serif title, optional media" viewport="700x300" */
export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  eyebrow?: string; index?: number; title?: React.ReactNode;
  /** true renders a striped placeholder; pass a node for real media */
  media?: boolean | React.ReactNode;
  href?: string; tone?: 'surface'|'muted'|'tint'|'inverse'; padding?: number;
  children?: React.ReactNode;
}
export function Card(props: CardProps): JSX.Element;