import React from 'react';
export function Accordion({ items=[], defaultOpen=0 }) {
  const [open,setOpen] = React.useState(defaultOpen);
  return <div style={{ borderTop:'var(--border-1)' }}>{items.map((it,i)=>{
    const isOpen = open===i;
    return <div key={i} style={{ borderBottom:'var(--border-1)' }}>
      <button onClick={()=>setOpen(isOpen?-1:i)} style={{ all:'unset', display:'flex', width:'100%', boxSizing:'border-box', alignItems:'baseline', gap:24, padding:'20px 0', cursor:'pointer', color:'var(--text-primary)' }}>
        <span style={{ font:'var(--text-mono)',letterSpacing:'var(--tracking-mono)',textTransform:'uppercase', color:'var(--text-tertiary)', width:32 }}>{String(i+1).padStart(2,'0')}</span>
        <span style={{ flex:1, font:'var(--text-display-s)', letterSpacing:'var(--tracking-display)', fontSize:26 }}>{it.q}</span>
        <span style={{ font:'var(--text-display-s)', fontSize:26, color: isOpen?'var(--accent)':'var(--text-tertiary)', transition:'transform var(--dur-base) var(--ease-out)', transform: isOpen?'rotate(45deg)':'none' }}>+</span>
      </button>
      {isOpen && <div style={{ padding:'0 0 24px 56px', font:'var(--text-body)', color:'var(--text-secondary)', maxWidth:'60ch' }}>{it.a}</div>}
    </div>; })}</div>;
}