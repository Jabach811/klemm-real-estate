Pill-shaped button for CTAs and nav actions; primary for most, accent (orange) at most once per screen.
```jsx
<Button arrow>Start a project</Button>
<Button variant="secondary" size="s">See pricing</Button>
<Button variant="accent" arrow="external" href="https://…">Live site</Button>
```
Variants: primary (ink → orange hover), accent, secondary (outlined), ghost. Sizes s/m/l.