import React from 'react';
export function Tag({ children, tone='neutral', style }) {
  const t = { neutral:{bg:'var(--bg-muted)',fg:'var(--text-secondary)'}, tint:{bg:'var(--bg-tint)',fg:'var(--teal-700)'}, accent:{bg:'var(--accent-soft)',fg:'var(--orange-600)'}, outline:{bg:'transparent',fg:'var(--text-primary)',border:'1px solid var(--border-subtle)'} }[tone];
  return <span style={{ display:'inline-flex', alignItems:'center', padding:'4px 10px', borderRadius:'var(--radius-pill)', background:t.bg, color:t.fg, border:t.border||'1px solid transparent', font:'var(--text-mono)',letterSpacing:'var(--tracking-mono)',textTransform:'uppercase', ...style }}>{children}</span>;
}