Mono uppercase caption/eyebrow, optionally prefixed with a zero-padded index — sits above every headline and on figure captions.
```jsx
<Eyebrow index={2} total={4}>Services</Eyebrow>
<Eyebrow tone="tertiary">Fig. 1 — Homepage</Eyebrow>
```