import React from 'react';
export function Input({ label, hint, multiline=false, style, ...rest }) {
  const [focus,setFocus] = React.useState(false);
  const field = { width:'100%', boxSizing:'border-box', padding:'14px 16px', font:'var(--text-body)', color:'var(--text-primary)', background:'var(--bg-surface)', border:'1px solid', borderColor: focus?'var(--focus-ring)':'var(--border-subtle)', borderRadius:'var(--radius-s)', outline:'none', boxShadow: focus?'0 0 0 3px var(--teal-100)':'none', transition:'box-shadow var(--dur-fast), border-color var(--dur-fast)', resize:'vertical' };
  const Tag = multiline ? 'textarea' : 'input';
  return <label style={{ display:'flex', flexDirection:'column', gap:8, ...style }}>
    {label && <span style={{ font:'var(--text-mono)',letterSpacing:'var(--tracking-mono)',textTransform:'uppercase', color:'var(--text-secondary)' }}>{label}</span>}
    <Tag style={field} rows={multiline?4:undefined} onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)} {...rest} />
    {hint && <span style={{ font:'var(--text-body-s)', color:'var(--text-tertiary)' }}>{hint}</span>}
  </label>;
}