import * as React from 'react';
export interface AccordionProps { items: { q: React.ReactNode; a: React.ReactNode }[]; defaultOpen?: number; }
export function Accordion(props: AccordionProps): JSX.Element;