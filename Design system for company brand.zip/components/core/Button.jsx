import React from 'react';
const base = { display:'inline-flex', alignItems:'center', gap:8, borderRadius:'var(--radius-pill)', border:'1px solid transparent', font:'var(--text-ui)', cursor:'pointer', transition:'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)', textDecoration:'none', whiteSpace:'nowrap' };
const sizes = { s:{padding:'8px 14px',fontSize:14}, m:{padding:'12px 20px'}, l:{padding:'16px 28px',fontSize:17} };
const variants = {
  primary:  { bg:'var(--ink-900)', fg:'var(--text-inverse)', hoverBg:'var(--accent)', border:'transparent' },
  accent:   { bg:'var(--accent)', fg:'#fff', hoverBg:'var(--accent-hover)', border:'transparent' },
  secondary:{ bg:'transparent', fg:'var(--text-primary)', hoverBg:'var(--bg-muted)', border:'var(--border-strong)' },
  ghost:    { bg:'transparent', fg:'var(--text-primary)', hoverBg:'var(--bg-muted)', border:'transparent' },
};
export function Button({ variant='primary', size='m', arrow=false, disabled=false, href, children, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const v = variants[variant] || variants.primary;
  const s = { ...base, ...sizes[size], background: hover && !disabled ? v.hoverBg : v.bg, color: v.fg, borderColor: v.border, opacity: disabled ? .4 : 1, pointerEvents: disabled ? 'none' : 'auto', ...style };
  const Tag = href ? 'a' : 'button';
  return <Tag href={href} style={s} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)} disabled={disabled} {...rest}>{children}{arrow && <span aria-hidden="true">{arrow === 'external' ? '↗' : '→'}</span>}</Tag>;
}