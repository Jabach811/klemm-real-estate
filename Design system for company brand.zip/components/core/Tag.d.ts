import * as React from 'react';
export interface TagProps { tone?: 'neutral'|'tint'|'accent'|'outline'; children?: React.ReactNode; style?: React.CSSProperties; }
export function Tag(props: TagProps): JSX.Element;