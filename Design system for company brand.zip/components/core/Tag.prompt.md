Small mono pill for categories and metadata (Webflow, 2026, New).
```jsx
<Tag>Webflow</Tag> <Tag tone="accent">New</Tag>
```