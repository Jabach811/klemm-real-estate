import React from 'react';
import { Eyebrow } from './Eyebrow.jsx';
export function Card({ eyebrow, index, title, children, media, href, tone='surface', padding=24, style, ...rest }) {
  const [hover,setHover] = React.useState(false);
  const bg = { surface:'var(--bg-surface)', muted:'var(--bg-muted)', tint:'var(--bg-tint)', inverse:'var(--bg-inverse)' }[tone];
  const inverse = tone==='inverse';
  const Tag = href ? 'a' : 'div';
  return <Tag href={href} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)} style={{ display:'flex', flexDirection:'column', gap:16, padding, background:bg, color: inverse?'var(--text-inverse)':'var(--text-primary)', borderRadius:'var(--radius-m)', border: tone==='surface' ? 'var(--border-1)' : '1px solid transparent', boxShadow: hover && href ? 'var(--shadow-card)' : 'none', transition:'box-shadow var(--dur-base) var(--ease-out)', textDecoration:'none', ...style }} {...rest}>
    {media && <div style={{ borderRadius:'var(--radius-s)', overflow:'hidden', aspectRatio:'4/3', background:'repeating-linear-gradient(135deg,var(--ink-200) 0 6px,var(--ink-100) 6px 12px)' }}>{media !== true && media}</div>}
    {eyebrow && <Eyebrow index={index} tone={inverse?'tertiary':'secondary'}>{eyebrow}</Eyebrow>}
    {title && <div style={{ font:'var(--text-display-s)', letterSpacing:'var(--tracking-display)' }}>{title}</div>}
    {children && <div style={{ font:'var(--text-body)', color: inverse?'var(--ink-200)':'var(--text-secondary)' }}>{children}</div>}
  </Tag>;
}