Numbered FAQ/expandable list with serif questions and a "+" that rotates and turns orange when open.
```jsx
<Accordion items={[{q:'How long does it take?', a:'About six weeks.'}]} />
```