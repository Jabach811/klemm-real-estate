Text field with a mono eyebrow label; teal focus ring. multiline for textareas.
```jsx
<Input label="Email" placeholder="you@studio.com" />
<Input label="Tell me about it" multiline />
```