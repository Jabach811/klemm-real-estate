import React from 'react';
/** Mono uppercase label. index + total renders "01 / 04". */
export function Eyebrow({ index, total, children, tone='secondary', style }) {
  const color = { primary:'var(--text-primary)', secondary:'var(--text-secondary)', tertiary:'var(--text-tertiary)', accent:'var(--accent)' }[tone];
  const pad = n => String(n).padStart(2,'0');
  return <div style={{ display:'flex', gap:24, font:'var(--text-mono)',letterSpacing:'var(--tracking-mono)',textTransform:'uppercase', color, ...style }}>
    {index != null && <span style={{color:'var(--text-tertiary)'}}>{pad(index)}{total != null && <span> / {pad(total)}</span>}</span>}
    <span>{children}</span>
  </div>;
}