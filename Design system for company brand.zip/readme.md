# Studio Design System

Design system for a one-person web design business (not yet named; the wordmark is the placeholder **Studio.** with an orange full stop — swap the word, keep the dot). Surfaces: marketing website, slide decks, printed/PDF documents.

## Sources
- `uploads/Design Systems/colors 1–7.png` — palette moodboard. The user chose the **Monochrome Beach** family (#353535, #3A6467, #FFFFFF, #DCDCDC, #2A4A63) as the core with **orange** as a rare accent.
- `uploads/Design Systems/Screenshot 2026-09-06 *.png` — typography references (Sidebearings, Fédération de la Haute Couture, Graydon Herriott, Claxton Projects, Watson, Stripe Dev, Forensic Architecture, MJ2B, CoType Foundry…). Take-aways: high-contrast serif display, grotesque body, small tracked index numbers/captions, text mixed with tiny images, generous whitespace, near-monochrome with one punch colour.
- Local folder "Work" was attached but the user said to ignore it.
- No logo, brand assets or licensed fonts were provided.

## Content fundamentals
- **Voice:** first person singular ("I design and build…"). The reader is "you". One person talking to one person.
- **Tone:** plain, direct, lightly playful. Short sentences. Concrete numbers ("about six weeks", "one fixed price") over adjectives. Humour comes from candour, not jokes.
- **Casing:** sentence case everywhere in body and headlines. Labels are UPPERCASE grotesque with +0.1em tracking.
- **Emphasis:** the last word or two of a headline in *italic serif* ("people who *notice.*", "One *price.*"). Never bold in headlines.
- **No emoji.** Unicode arrows are used as glyphs: → (internal), ↗ (external/live site), + (expand).
- **Numbers:** zero-padded indices (01, 02…) as structure; "Fig. 1" captions on imagery.
- Examples: "I make websites for people who notice." / "Plain process. One price." / "Then a month of fixes, on me."

## Visual foundations
- **Colour:** cool white page (`--ink-50` #f7f8f8), white surfaces, ink greys for text. Teal (#3a6467) is the secondary tone (tints, focus ring, links in decks); navy appears only in imagery tints. **Orange (#e8622a) is a rare punch: at most one orange element per screen** — the wordmark dot, a primary CTA hover, or one accent tag. Never orange backgrounds behind text.
- **Type:** Instrument Serif (display, 400 only, italic for emphasis, 0.92–1.08 leading, −0.02em). Hanken Grotesk (body 400/500/600, −0.005em). Labels are the same grotesque at 11–12px/500, uppercase, +0.1em (no monospace; it clashed with the serif). Display sizes: 136 / 88 / 56 / 32.
- **Spacing:** 4-based scale to 144. Sections separated by 96px. Container 1280, fluid gutters. Density: balanced — airy hero, denser lists.
- **Corners:** soft. 8 (inputs, small media), 12 (cards), 20 (large media), pill buttons and tags.
- **Borders:** 1px `--ink-200` hairlines do most of the structural work (list rows, cards, footer). Strong 1px ink border for secondary buttons.
- **Shadows:** none by default. `--shadow-card` only on hovered link-cards; `--shadow-pop` for dialogs.
- **Backgrounds:** flat colour. No gradients, no textures, no patterns. Imagery placeholders are 135° hairline stripes in ink/teal/navy tints with a mono label.
- **Imagery:** cool, natural light, low saturation, real work (site screenshots, studio photos). Tiny inline images (40px tall, radius 6) set into running serif text is the signature playful device.
- **Motion:** 150ms colour transitions, 240ms shadow/rotation, ease-out. No bounces, no entrance animations, no underline animations.
- **Hover:** primary button ink → orange; links ink → orange; link-cards gain shadow; accordion "+" rotates 45° and turns orange.
- **Press/focus:** no shrink. Focus is a 1px teal border + 3px teal-100 ring.
- **Layout:** left-aligned, top nav 72px, two-column sections (headline left, content right), 3-column card grids. Nothing fixed/sticky.
- **Transparency/blur:** not used.
- **Cards:** white, 1px border, radius 12, 24px padding, eyebrow → serif title → grey body. Tint (neutral cool grey #eef0f1) and inverse (ink-800) variants for emphasis.

## Iconography
No icon set. Glyphs are typographic: → ↗ + and zero-padded numerals in the grotesque. If icons become necessary, use Lucide (1.5px stroke) at 16–20px in `--text-secondary`; flag it here. No emoji, no PNG icons.

## Fonts
All three faces are loaded from Google Fonts in `tokens/fonts.css` (Instrument Serif, Hanken Grotesk). **Substitution flag:** these are open-source stand-ins for the licensed high-contrast serif / grotesque seen in the references. If you license fonts, drop the files in `assets/fonts/` and replace the @import with @font-face rules.

## Index
- `styles.css` — entry; imports `tokens/{fonts,colors,typography,spacing,base}.css`
- `guidelines/` — 15 foundation cards (Colors, Type, Spacing, Brand)
- `components/core/` — Button, Eyebrow, Tag, Card, Accordion, Input (+ .d.ts, .prompt.md, core.card.html)
- `ui_kits/website/` — marketing site: Home, Services, Pricing (index.html click-through)
- `slides/` — six 1280×720 slide layouts
- `documents/` — Letter-size proposal cover, proposal body, invoice
- `overview.html` — every piece on one canvas
- `ds-loader.js` — dev fallback that loads components directly when the generated bundle is absent
- `SKILL.md` — agent skill entry point

## Intentional additions
- Eyebrow and Accordion are not in a "standard" set; both come straight from the reference screenshots (index numbers, numbered lists).
- No logo was provided, so none was drawn. Wordmark is plain type.
