// Dev fallback: loads components/core/*.jsx directly when _ds_bundle.js is absent.
// Usage: await window.loadDS(rootRel) -> namespace object
window.loadDS = async function(root){
  for (const k of Object.getOwnPropertyNames(window)) {
    try { const v = window[k]; if (v && typeof v === 'object' && v.Button && v.Card && v.Eyebrow) return v; } catch (e) {}
  }
  const names = ['Eyebrow','Button','Tag','Card','Accordion','Input'];
  const DS = window.DS = {};
  for (const n of names) {
    let src = await (await fetch(root + 'components/core/' + n + '.jsx')).text();
    src = src.replace(/^import React.*$/m, '')
             .replace(/^import \{([^}]+)\} from '\.\/\w+\.jsx';$/gm, 'const {$1} = DS;')
             .replace(/^export function (\w+)/m, 'DS.$1 = function $1');
    const js = Babel.transform(src, { presets:['react'] }).code;
    new Function('React','DS', js)(React, DS);
  }
  return DS;
};
// Fetch + transpile plain JSX files (no import/export) in order.
window.loadJSX = async function(paths){
  for (const p of paths) {
    const src = await (await fetch(p)).text();
    try { new Function('React', Babel.transform(src, { presets:['react'], filename:p }).code)(React); }
    catch (e) { console.error('loadJSX ' + p, e); throw e; }
  }
};